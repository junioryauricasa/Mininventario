<?php
	$servidor = 'localhost';
    $user = 'root';
    $pass = '';
    $name = 'db_portfoliogame';
?>